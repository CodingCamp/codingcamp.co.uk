var red = [0, 100, 63];
var orange = [40, 100, 60];
var green = [85, 100, 67];
var blue = [172, 100, 67];
var purple = [280, 50, 60];
var yellow = [55,100,67];

var myName = "Sophie.J";
var letterColors = [purple,red,green,yellow, blue];
bubbleShape = "circle";



drawName(myName, letterColors);
bounceBubbles();